package com.nehal.telegrammonitor;

public class CameraHelper { public static void takePhoto(...) {} public static void captureFront(...) {} public static void captureBack(...) {} }