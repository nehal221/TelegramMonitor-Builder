package com.nehal.telegrammonitor;

public class AppHider { public static void enableHide(...) {} public static void disableHide(...) {} }