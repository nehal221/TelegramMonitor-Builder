package com.nehal.telegrammonitor;

public class LocationHelper { public static void sendLocation(...) {} }