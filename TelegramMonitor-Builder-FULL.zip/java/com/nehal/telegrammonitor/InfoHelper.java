package com.nehal.telegrammonitor;

public class InfoHelper {
        public static void sendCallLogs(...) {}
        public static void sendSms(...) {}
        public static void sendContacts(...) {}
        public static void sendWifiInfo(...) {}
        public static void sendBatteryStatus(...) {}
        public static void sendInstalledApps(...) {}
        public static void sendAppUsage(...) {}
        public static void sendGalleryImages(...) {}
    }