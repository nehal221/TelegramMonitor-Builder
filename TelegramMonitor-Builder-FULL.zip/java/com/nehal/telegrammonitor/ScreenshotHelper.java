package com.nehal.telegrammonitor;

public class ScreenshotHelper { public static void takeScreenshot(...) {} }