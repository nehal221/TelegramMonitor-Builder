package com.nehal.telegrammonitor;

public class TelegramUploader { public static void upload(...) {} }