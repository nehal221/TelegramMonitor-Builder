package com.nehal.telegrammonitor;

public class AdminReceiver extends android.app.admin.DeviceAdminReceiver {}