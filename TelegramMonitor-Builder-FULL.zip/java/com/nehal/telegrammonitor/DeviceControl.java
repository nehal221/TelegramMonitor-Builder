package com.nehal.telegrammonitor;

public class DeviceControl { public static void lockNow(...) {} public static void rebootDevice(...) {} }